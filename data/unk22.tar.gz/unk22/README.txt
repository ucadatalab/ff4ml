The UNK22 derived dataset is built from the integration of the UGR'16, UNSW-NB15 and NSL-KDD derived datasets after FaaC transformation following a row-wise integration approach.
It comprises only the clases the three last dataset shared which are named as background, dos and scan for Background traffic and DoS and Port Scanning attacks respectively. 
Two version of the UNK22 are comprises in this file:
- unk22_10K.csv: it integrates the 10K version of UGR'16, UNSW-NB15 and NSL-KDD derived datasets.
- unk22_20K.csv: it integrates the 20K version of UGR'16, UNSW-NB15 and NSL-KDD derived datasets.
Interested readers are kindly referenced to the involved paper.
